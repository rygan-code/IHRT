        logical new
 	integer nx,ny,nz,nx_input,ny_input,nz_input,hx,hy,hz,hhz,dx,dy,dz,nproc,input_nproc,  &
                    npart,lx,ly,lz,lx_input,ly_input,lz_input,lx1,lx2

        common /dimen/nx,ny,nz,nx_input,ny_input,nz_input,hx,hy,hz,hhz,dx,dy,dz,nproc,input_nproc,  &
                    npart,lx,ly,lz,lx_input,ly_input,lz_input,lx1,lx2
        
! --------------------------------------------------------------

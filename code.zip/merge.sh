#!/bin/bash

for	(( num = $1;$num < $2;num++ ));
do
#	a = $(($num/100))
#	b = $(($num-$(($a*100))))
#	c = $(($num-$(($a*100))-$(($b*10))))
	cat	plot_number$(($num/10))$(($(($num-$(($(($num/10))*10))))))_*.dat >> merge_Q_$(($num/10))$(($(($num-$(($(($num/10))*10)))))).dat
	cat	Q_criterion_$(($num/10))$(($(($num-$(($(($num/10))*10))))))_*.dat >> merge_Q_$(($num/10))$(($(($num-$(($(($num/10))*10)))))).dat
	mv	plot_number$(($num/10))$(($(($num-$(($(($num/10))*10))))))_*.dat ./trash/
	mv	Q_criterion_$(($num/10))$(($(($num-$(($(($num/10))*10))))))_*.dat ./trash/
	echo	$num
#	echo $(($num/100))
#	echo $(($(($num-$(($(($num/100))*100))))/10))
#	echo $(($num-$(($(($num/100))*100))-$(($(($(($num-$(($(($num/100))*100))))/10))*10))))
#	echo
done
rm	vel00000.*

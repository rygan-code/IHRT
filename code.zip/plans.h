!==================================================================
! Include file for plans in FFTW
!
       
     INTEGER*8      ::  plan1DF, plan1DB, plan2DRC, plan2DCR, plan1DF_lx2, plan1DB_lx2

     COMMON / plans / plan1DF, plan1DB, plan2DRC, plan2DCR, plan1DF_lx2, plan1DB_lx2

!==================================================================
